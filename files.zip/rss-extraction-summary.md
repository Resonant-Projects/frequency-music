# RSS Feed Extraction — Section V Summary

## Source Document
**"The Resonant Fabric: A Holistic Survey of Frequency, Music, Mathematics, and Physical Reality"**

Extracted from Section V: The Comprehensive Source Ecosystem

---

## Extraction Statistics

| Category | Count | With RSS | Notes |
|----------|-------|----------|-------|
| Academic Journals | 10 | 8 | JASA, Music Perception, JMM, CMJ, Organised Sound, JSE, Leonardo, GAIM |
| Magazines | 5 | 3 | Quanta (full), SOS (full), Nautilus (partial) |
| Labs/Archives | 5 | 2 | MPI Aesthetics, BRAMS (needs scraping for others) |
| YouTube Channels | 6 | 6 | All have RSS via YouTube feed format |
| Podcasts | 2 | 2 | LoC Music and Brain, Sounding Out! |
| Conferences | 4 | 0 | Manual monitoring required |

**Total Feeds Ready for n8n:** 21

---

## Priority Tiers

### Tier 1: Poll Every 6 Hours (Core Research)
- **JASA** — Acoustical Society of America (acoustics, psychoacoustics)
- **Music Perception** — UC Press (cognition, neuroscience)  
- **Journal of Mathematics and Music** — Taylor & Francis (math, computation)
- **Quanta Magazine** — Simons Foundation (math/physics journalism)
- **3Blue1Brown** — Grant Sanderson (visual math, Fourier)
- **Adam Neely** — Music theory, tuning, 432Hz research
- **Library of Congress: Music and the Brain** — Neuroscience podcast

### Tier 2: Poll Every 12 Hours (Supporting)
- Computer Music Journal
- Organised Sound
- Sound On Sound
- Global Advances in Integrative Medicine
- David Bennett Piano
- Andrew Huang

### Tier 3: Poll Daily (Frontier/Niche)
- Journal of Scientific Exploration (consciousness, biofields)
- CymaScope (cymatics visualization)
- Nautilus
- Leonardo
- Sounding Out! podcast

### Tier 4: Weekly/Manual (Static Resources)
- UNSW Music Acoustics (Prof. Joe Wolfe)
- CCRMA Stanford archives
- Sethares homepage
- BRAMS news

---

## Priority Ingestion Queue

These should be ingested **immediately** as foundational resources before RSS polling:

1. **Synth Secrets Series** (63 parts)  
   `https://www.soundonsound.com/series/synth-secrets-sound-sound`  
   → Best practical synthesis physics course

2. **3B1B: But what is the Fourier Transform?**  
   `https://www.youtube.com/watch?v=spUNpyF58BY`  
   → Essential frequency visualization

3. **Andrew Huang: Harmonic Series**  
   `https://www.youtube.com/watch?v=Wx_kugSemfY`  
   → Cited in source document

4. **Sethares: Tuning, Timbre, Spectrum, Scale Overview**  
   `https://sethares.engr.wisc.edu/prelude.html`  
   → Foundation for timbre-tuning compositional recipes

5. **John Stuart Reid: Secrets of Cymatics II**  
   `https://www.youtube.com/watch?v=K8w_frOvfGo`  
   → Primary cymatics research

6. **UNSW Voice Acoustics**  
   `https://www.phys.unsw.edu.au/jw/voice.html`  
   → Human body as resonator

---

## n8n Setup Instructions

### Environment Variables Required
```
CONVEX_INGEST_BASE_URL=https://your-convex-deployment.convex.site
CONVEX_INGEST_SECRET=your-shared-secret
```

### Workflow Import
1. Open n8n at `zap.rproj.art`
2. Create new workflow
3. Import `n8n-rss-workflow.json`
4. Set environment variables in n8n credentials
5. Activate workflow

### Testing
Before activating the schedule:
1. Manually trigger the workflow
2. Check that feeds resolve (some may require adjusting URLs)
3. Verify Convex endpoint receives payloads
4. Monitor for rate limiting on YouTube feeds

---

## Topics Covered (for extraction tagging)

From Section V sources, the following topic tags should be used:

**Physics/Acoustics:**
- `acoustics`, `wave_mechanics`, `resonance`, `harmonic_series`, `cymatics`

**Mathematics:**
- `math`, `tuning_systems`, `pythagorean_comma`, `geometric_music_theory`, `fourier`

**Psychoacoustics/Neuroscience:**
- `psychoacoustics`, `cognition`, `perception`, `entrainment`, `roughness`, `critical_bands`

**Frontier Science:**
- `quantum_biology`, `consciousness`, `biofields`, `frolich_condensation`, `liquid_crystal`

**Applied/Compositional:**
- `synthesis`, `dsp`, `tuning`, `timbre`, `production`, `sound_healing`, `vibroacoustic_therapy`

---

## Schema Validation Notes

The extraction from Section V validated:

✅ `sources.type` — supports `url`, `youtube`, `pdf`, `rss` types  
✅ `sources.feedUrl` — new field needed for RSS origin tracking  
✅ `extractions.topics[]` — tag taxonomy confirmed  
✅ `extractions.compositionParameters[]` — types cover frequency, tuningSystem, harmonicProfile  
⚠️ `extractions.openQuestions[]` — in prompts.md but missing from schema.md  

**Action:** Add `openQuestions: v.optional(v.array(v.string()))` to `extractions` table in schema.md
